# A frozendict can be hashed if all its keys and values can also be hashed
d_config =       dict(host="localhost", port=8080)
f_config = frozendict(host="localhost", port=8080)

# Use frozendict as a dict key
servers = {d_config: "primary"}
servers = {f_config: "primary"}

# Use frozendict in a set
seen = {d_config}
seen = {f_config}

# Use frozendict with cache decorator
from functools import cache

@cache
def connect(config):
    return f"connecting to {config['host']}:{config['port']}"

connect(d_config)
connect(f_config)
