"""
https://peps.python.org/pep-0810/
https://docs.python.org/3/whatsnew/3.15.html#whatsnew315-lazy-imports
https://github.com/python-pillow/Pillow/pull/9733#issuecomment-5231395200
https://hugovk.dev/blog/2025/lazy-imports/
python3.15 lazy_demo.py 3
python3.15 lazy_demo.py 1 4 5
python3.15 -X importtime -c "import lazy_demo"
python3.15 -X importtime -c "import lazy_demo" 2> my.log
uvx tuna my.log
__lazy_modules__ = {"numpy"}
PYTHON_LAZY_IMPORTS=all
"""
import sys
import numpy as np

if __name__ == "__main__":
    args = [float(x) for x in sys.argv[1:]]
    if len(args) == 1:
        print(args[0] ** 2)  # numpy never used
    else:
        print(np.exp(-np.array(args) ** 2 / 2) / np.sqrt(2 * np.pi))
