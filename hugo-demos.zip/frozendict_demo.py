"""
https://docs.python.org/3/whatsnew/3.15.html#whatsnew315-frozendict
https://peps.python.org/pep-0814/
"""

d = dict(x=1, y=2)
print(d)
d["z"] = 3
print(d)

f = frozendict(x=1, y=2)
print(f)
f["z"] = 3
print(f)
